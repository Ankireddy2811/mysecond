import {Component} from 'react'

import MovieCard from '../MovieCard'

class AllMovies extends Component {
  state = {moviesList: []}

  componentDidMount() {
    this.getMoviesData()
  }

  getMoviesData = async () => {
    const response = await fetch('https://api.tvmaze.com/search/shows?q=all')

    const data = await response.json()
    const updatedData = data.map(eachItem => ({
      id: eachItem.show.id,
      imageData: eachItem.show.image,
      title: eachItem.show.name,
      rating: eachItem.show.rating.average,
      genres: eachItem.show.genres,
      language: eachItem.show.language,
      premiered: eachItem.show.premiered,
      runtime: eachItem.show.runtime,
      summary: eachItem.show.summary,
      url: eachItem.show.url,
    }))

    this.setState({moviesList: updatedData})
  }

  render() {
    const {moviesList} = this.state
    console.log(moviesList)

    return (
      <div className="movies-sections">
        <ul className="movies-list">
          {moviesList.map(movieItem => (
            <MovieCard movieData={movieItem} key={movieItem.id} />
          ))}
        </ul>
      </div>
    )
  }
}

export default AllMovies
