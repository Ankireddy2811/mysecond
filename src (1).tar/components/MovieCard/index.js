import {Link} from 'react-router-dom'

import './index.css'

const MovieCard = props => {
  const {movieData} = props
  console.log(movieData)
  const {title, premiered, imageData, rating, genres, id, language} = movieData
  let imageUrl
  if (imageData === null) {
    imageUrl = ''
  } else {
    imageUrl = imageData.medium
  }

  return (
    <button type="button" className="link-item">
      <li className="product-item ">
        <img src={imageUrl} alt="imageNotFound" className="thumbnail" />
        <div className="view-title-container">
          <h1 className="title">{title}</h1>
          <Link to={`/movies/${id}`}>
            <button type="button" className="button5">
              View
            </button>
          </Link>
        </div>
        <p className="brand">{premiered}</p>
        <div className="product-details">
          <p className="language">{language}</p>
          <div className="rating-container">
            <p className="rating">{rating}</p>
            <img
              src="https://assets.ccbp.in/frontend/react-js/star-img.png"
              alt="star"
              className="star"
            />
          </div>
        </div>
        <ul className="unordered-time">
          {genres.map(eachItem => (
            <li className="each-genre">{eachItem}</li>
          ))}
        </ul>
      </li>
    </button>
  )
}
export default MovieCard
