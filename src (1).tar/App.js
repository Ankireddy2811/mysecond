import {Switch, Route} from 'react-router-dom'

import NotFound from './components/NotFound'
import AllMovies from './components/AllMovies'
import SummaryData from './components/SummaryData'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/" component={AllMovies} />
    <Route exact path="/movies/:id" component={SummaryData} />
    <Route component={NotFound} />
  </Switch>
)

export default App
